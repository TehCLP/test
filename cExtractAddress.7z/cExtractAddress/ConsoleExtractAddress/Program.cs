﻿using System;
using System.Collections.Generic;
using System.Data; 
using System.Linq;
using System.Text;

namespace ConsoleExtractAddress
{
    class Program
    {
        static void Main(string[] args)
        {
            //run.Extract_debug();

            run.Extract();
        }
    }
}
